// Predefined password for login
const password = 'ixmee12354';

// Simulate some initial messages
let messages = [];

// Simulate other user messages
const otherUserMessages = [
    "Hello! How are you?",
    "I'm fine, thank you! How about you?",
    "Let's chat later, I have to go."
];

// Check if the user is logged in on page load
document.addEventListener("DOMContentLoaded", function () {
    console.log("Checking if logged in...");
    if (localStorage.getItem('isLoggedIn') === 'true') {
        showChatRoom();
    } else {
        showLoginPage();
    }
});

// Login function
function login() {
    const enteredPassword = document.getElementById('passwordInput').value;
    console.log("Entered Password:", enteredPassword);
    
    if (enteredPassword === password) {
        // Set logged in status
        localStorage.setItem('isLoggedIn', 'true');
        showChatRoom();
    } else {
        document.getElementById('errorMessage').innerText = "Incorrect password, please try again!";
    }
}

// Show the chat room after login
function showChatRoom() {
    console.log("Showing Chat Room...");
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('chatRoomPage').style.display = 'block';

    // Add predefined messages (your messages + some from other users)
    displayMessages();
}

// Show the login page if not logged in
function showLoginPage() {
    console.log("Showing Login Page...");
    document.getElementById('loginPage').style.display = 'block';
    document.getElementById('chatRoomPage').style.display = 'none';
}

// Logout function
function logout() {
    console.log("Logging out...");
    localStorage.removeItem('isLoggedIn');
    window.location.reload();
}

// Handle message input (enter key support)
function handleInput(event) {
    if (event.key === "Enter") {
        sendMessage();
    }
}

// Send message function
function sendMessage() {
    const messageInput = document.getElementById('messageInput');
    const message = messageInput.value.trim();

    if (message !== "") {
        // Add your message to the messages array
        messages.push({ from: 'me', message });

        // Display the message
        displayMessages();

        // Clear the input field
        messageInput.value = '';
    }
}

// Display messages function
function displayMessages() {
    const chatMessagesContainer = document.getElementById('chatMessages');

    // Clear previous messages
    chatMessagesContainer.innerHTML = '';

    // Add the new messages (your messages + others' messages)
    const allMessages = [...messages, ...otherUserMessages];

    allMessages.forEach((msg, index) => {
        const messageElement = document.createElement('div');
        messageElement.classList.add(msg.from === 'me' ? 'message-me' : 'message-other');
        messageElement.innerText = msg.message;
        chatMessagesContainer.appendChild(messageElement);
    });

    // Scroll to the bottom of chat messages
    chatMessagesContainer.scrollTop = chatMessagesContainer.scrollHeight;
}